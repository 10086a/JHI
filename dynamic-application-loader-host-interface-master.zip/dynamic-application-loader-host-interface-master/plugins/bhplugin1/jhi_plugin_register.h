#ifndef __JHI_PLUGIN1_REGISTER_H__
#define __JHI_PLUGIN1_REGISTER_H__

#include "plugin_interface.h"

namespace Jhi_Plugin_1
{
	UINT32 pluginRegister(VM_Plugin_interface** plugin);
}

#endif //__JHI_PLUGIN1_REGISTER_H__