#ifndef __JHI_PLUGIN2_REGISTER_H__
#define __JHI_PLUGIN2_REGISTER_H__

#include "plugin_interface.h"

namespace Jhi_Plugin_2
{
	UINT32 pluginRegister(VM_Plugin_interface** plugin);
}

#endif //__JHI_PLUGIN2_REGISTER_H__