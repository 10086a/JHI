#!/bin/bash

systemd-tmpfiles --create /usr/lib/tmpfiles.d/jhi.conf
